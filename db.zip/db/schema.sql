DROP DATABASE IF EXISTS tech_blog_db;

CREATE DATABASE tech_blog_db;